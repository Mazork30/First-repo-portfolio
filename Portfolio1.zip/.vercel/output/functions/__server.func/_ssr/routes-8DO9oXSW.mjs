import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as Copy, i as Mail, o as Check, r as Menu, s as ArrowUpRight, t as X } from "../_libs/lucide-react.mjs";
import { i as string, r as object } from "../_libs/zod.mjs";
import { a as DialogOverlay, i as DialogDescription, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-8DO9oXSW.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var site = {
	name: "Hiller Lozano",
	role: "Diseñador UX",
	email: "hola@hillerlozano.design"
};
var projects = [
	{
		slug: "veloce",
		index: "01",
		title: "Veloce",
		discipline: "Producto",
		year: "2025",
		summary: "HUD de telemetría para pilotos amateur. El dato crítico se lee sin apartar la vista de la trazada.",
		image: "/portfolio/veloce.jpg",
		alt: "Vista desde el cockpit de un auto de carreras de noche, volante y luces ámbar sobre asfalto mojado.",
		role: "Diseño de producto, de la investigación al prototipo",
		context: "Un equipo de simracing quería sacar la telemetría del portátil y ponerla en el visor. Los pilotos amateur llegaban a la curva mirando una tabla, no el ápice.",
		problem: "Las apps de datos heredan el lenguaje del ingeniero: todo visible, todo igual de importante. En pista eso es ruido. El piloto necesita una sola verdad y el resto en silencio.",
		moves: [
			"Sesiones en simulador para ver dónde se iba la mirada en los últimos doscientos metros.",
			"Tres niveles: delta, sector, y todo lo demás oculto hasta la recta.",
			"Prototipo probado con guantes y el auto en movimiento, no en un escritorio quieto."
		],
		outcome: "El delta vive en el centro del campo visual. La marcha y la temperatura solo aparecen cuando el ritmo baja. La interfaz deja de competir con la curva."
	},
	{
		slug: "frame-24",
		index: "02",
		title: "Frame 24",
		discipline: "Contenido",
		year: "2024",
		summary: "Descubrimiento para una plataforma de anime. El inicio se comporta como un opening, no como un estante.",
		image: "/portfolio/frame.jpg",
		alt: "Calle de noche bajo la lluvia, luces ámbar y rojas reflejadas en el asfalto, vista a través de un vidrio mojado.",
		role: "UX de contenido y arquitectura del primer visionado",
		context: "Una plataforma independiente de anime tenía catálogo de sobra y una portada que parecía un supermercado: filas, carátulas y cero pulso.",
		problem: "La gente no se va por falta de títulos. Se va porque nada le dice cuál es el siguiente. El scroll infinito diluye el deseo.",
		moves: [
			"Mapa de la primera sesión: de la llegada al play, sin un menú de géneros de por medio.",
			"Una pieza principal que cambia como una secuencia: frío, título, motivo y un solo llamado.",
			"Seguir viendo deja de ser una fila más y pasa a ser el cliffhanger de la sesión."
		],
		outcome: "Una sola decisión dominante por pantalla. El catálogo sigue ahí, detrás de un gesto, no delante de la emoción."
	},
	{
		slug: "pitwall",
		index: "03",
		title: "Pitwall",
		discipline: "Operaciones",
		year: "2025",
		summary: "Coordinación de boxes para endurance amateur. Stint, gomas y radio en una tira que se confirma con el pulgar.",
		image: "/portfolio/pitwall.jpg",
		alt: "Garage de boxes de noche, nariz roja de un prototipo y luces de trabajo cálidas.",
		role: "Diseño de operaciones y flujos bajo presión",
		context: "Una escudería de endurance corría con una hoja de cálculo, tres radios y la memoria del jefe de box. En la hora dieciocho, de noche, eso se cae.",
		problem: "La información existía, repartida. Confirmar un cambio de gomas pedía salir de la hoja, buscar la ventana y volver a hablar. Bajo bandera no hay tiempo para navegar.",
		moves: [
			"Observación de un stint entero, anotando qué se preguntaba en voz alta.",
			"Una tira fija: piloto, gomas, ventana, combustible. Lo demás se abre hacia abajo.",
			"Confirmaciones grandes, de pulgar, con estados imposibles de confundir: listo, en curso, hecho."
		],
		outcome: "El box deja de improvisar la secuencia. La pantalla no pide precisión de oficina: pide una decisión y la registra."
	},
	{
		slug: "senda",
		index: "04",
		title: "Senda",
		discipline: "Wayfinding",
		year: "2023",
		summary: "Señalética digital para un intercambiador. Tres segundos, una flecha, cero ornamento.",
		image: "/portfolio/senda.jpg",
		alt: "Gran vestíbulo de una estación al anochecer, luces ámbar en retícula y un reflejo rojo en el suelo.",
		role: "Wayfinding y sistema de señales en pantalla",
		context: "Un intercambiador urbano renovaba pantallas que repetían el mapa completo en cada punto. La gente se detenía en mitad del flujo.",
		problem: "Un mapa es una herramienta de escritorio. En un andén es una excusa para dudar. Quien camina con una maleta no quiere entender el sistema: quiere la salida.",
		moves: [
			"Recorridos con personas entre andén, calle y correspondencia.",
			"Regla de tres: nunca más de tres opciones en una pantalla de decisión.",
			"Lenguaje de circuito: número enorme, una flecha, minutos a pie. El mapa queda para quien lo pide."
		],
		outcome: "La pantalla empuja en lugar de retener. Quien necesita el sistema completo lo abre. Quien solo necesita salir, sale."
	}
];
var principles = [
	{
		index: "01",
		title: "Claridad a fondo",
		copy: "Si no se lee en un vistazo, no está diseñado. La jerarquía es una decisión, no un adorno."
	},
	{
		index: "02",
		title: "Ritmo de opening",
		copy: "El motion marca un cambio de estado. Si no cambia nada, la pantalla se queda quieta."
	},
	{
		index: "03",
		title: "El piloto manda",
		copy: "Primero la gente bajo presión real. La livery llega después, y solo si ayuda a decidir."
	},
	{
		index: "04",
		title: "Sistema, no piezas",
		copy: "Reglas que aguantan el siguiente release. Un producto no es una colección de pantallas."
	}
];
function About() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "sobre",
		className: "scroll-mt-16 border-b border-line",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-7xl gap-10 px-5 py-16 md:grid-cols-[minmax(0,0.85fr)_minmax(0,1.15fr)] md:px-8 md:py-24",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/portfolio/about.jpg",
				alt: "Casco de carreras cerrado sobre un plinto de carbono, con una franja roja y un filete ámbar.",
				width: 1200,
				height: 1600,
				loading: "lazy",
				className: "aspect-[3/4] w-full object-cover"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
				className: "mt-3 text-sm text-muted",
				children: "Visor abajo. La decisión, delante. El retrato puede esperar."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-kicker font-medium text-signal uppercase",
					children: "Sobre mí"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-poster text-5xl text-fg uppercase md:text-7xl",
					children: "Entre el box y el storyboard."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 space-y-4 text-lg leading-relaxed text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Me muevo entre dos obsesiones que parecen lejanas y no lo son. El automovilismo enseña a jerarquizar bajo presión: lo que no se lee a fondo, no existe. El anime enseña el ritmo: un encuadre, una pausa, un golpe." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Diseño productos con las dos cosas a la vez. Investigación con gente real, arquitectura que aguanta, prototipos que se pueden usar y sistemas que no se rompen en el segundo release. No colecciono pantallas. Colecciono decisiones que se sienten obvias después, y valientes antes." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-fg",
							children: "Estoy disponible para productos que necesiten claridad, carácter y una mano que sepa cuándo acelerar y cuándo levantar."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-8 grid gap-3 sm:grid-cols-2",
					children: principles.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "border border-line bg-surface p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-poster text-2xl text-racing",
								children: item.index
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-1 font-poster text-3xl leading-none text-fg uppercase",
								children: item.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-relaxed text-muted",
								children: item.copy
							})
						]
					}, item.index))
				})
			] })]
		})
	});
}
var schema = object({
	name: string().trim().min(2, "Dime cómo llamarte."),
	email: string().trim().email("Ese correo no parece válido."),
	project: string().trim().min(2, "Cuéntame el proyecto en una línea."),
	message: string().trim().min(12, "Un poco más de contexto, aunque sea breve.")
});
var empty = {
	name: "",
	email: "",
	project: "",
	message: ""
};
function compose(values) {
	return `Hola Hiller,\n\nSoy ${values.name} (${values.email}).\nProyecto: ${values.project}\n\n${values.message}`;
}
function mailto(values) {
	const subject = encodeURIComponent(`Proyecto: ${values.project}`);
	const body = encodeURIComponent(compose(values));
	return `mailto:${site.email}?subject=${subject}&body=${body}`;
}
function Contact() {
	const formId = (0, import_react.useId)();
	const [values, setValues] = (0, import_react.useState)(empty);
	const [errors, setErrors] = (0, import_react.useState)({});
	const [ready, setReady] = (0, import_react.useState)(null);
	const [copied, setCopied] = (0, import_react.useState)(false);
	function update(field, value) {
		setValues((current) => ({
			...current,
			[field]: value
		}));
		setErrors((current) => ({
			...current,
			[field]: void 0
		}));
	}
	function onSubmit(event) {
		event.preventDefault();
		const parsed = schema.safeParse(values);
		if (!parsed.success) {
			const next = {};
			for (const issue of parsed.error.issues) {
				const key = issue.path[0];
				if (typeof key === "string" && !next[key]) next[key] = issue.message;
			}
			setErrors(next);
			setReady(null);
			return;
		}
		setErrors({});
		setReady(parsed.data);
		setCopied(false);
	}
	async function copyMessage() {
		if (!ready) return;
		try {
			await navigator.clipboard.writeText(compose(ready));
			setCopied(true);
		} catch {
			setCopied(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "contacto",
		className: "scroll-mt-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-7xl gap-10 px-5 py-16 md:grid-cols-2 md:px-8 md:py-24",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-kicker font-medium text-signal uppercase",
					children: "Contacto"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-poster text-5xl text-fg uppercase md:text-7xl",
					children: "Cuéntame la próxima curva."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-xl text-lg leading-relaxed text-muted",
					children: "Qué tiene que lograr la persona al otro lado, qué restricción no se negocia y cómo debería sentirse el producto en los primeros diez segundos. Con eso alcanza para una primera lectura honesta."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: `mailto:${site.email}`,
					className: "mt-6 inline-flex items-center gap-2 text-lg font-medium text-signal",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, {
						"aria-hidden": "true",
						className: "h-5 w-5"
					}), site.email]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-md text-sm leading-relaxed text-muted",
					children: "Respondo en persona. Sin newsletter y sin automatización. El formulario prepara el mensaje para que lo envíes tú."
				})
			] }), ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border border-line bg-surface p-5 md:p-6",
				role: "status",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-poster text-4xl text-fg uppercase",
						children: "Mensaje listo"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-muted",
						children: "Cópialo o ábrelo en tu correo. Llega directo, sin intermediarios."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
						className: "mt-4 overflow-x-auto border border-line bg-bg p-4 text-sm leading-relaxed whitespace-pre-wrap text-fg",
						children: compose(ready)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: copyMessage,
								className: "inline-flex h-11 items-center gap-2 bg-racing px-4 text-sm font-semibold text-bg transition-transform duration-150 ease-out active:scale-[0.96]",
								children: [copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
									"aria-hidden": "true",
									className: "h-4 w-4"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {
									"aria-hidden": "true",
									className: "h-4 w-4"
								}), copied ? "Copiado" : "Copiar mensaje"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: mailto(ready),
								className: "inline-flex h-11 items-center border border-line px-4 text-sm font-semibold text-fg",
								children: "Abrir en el correo"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									setReady(null);
									setCopied(false);
								},
								className: "inline-flex h-11 items-center px-4 text-sm font-semibold text-muted",
								children: "Escribir otro"
							})
						]
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				noValidate: true,
				className: "border border-line bg-surface p-5 md:p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							id: `${formId}-name`,
							label: "Nombre",
							value: values.name,
							error: errors.name,
							autoComplete: "name",
							onChange: (value) => update("name", value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							id: `${formId}-email`,
							label: "Correo",
							type: "email",
							value: values.email,
							error: errors.email,
							autoComplete: "email",
							onChange: (value) => update("email", value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							id: `${formId}-project`,
							label: "Proyecto",
							value: values.project,
							error: errors.project,
							placeholder: "Una app, un rediseño, un sistema",
							onChange: (value) => update("project", value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "grid gap-2",
							htmlFor: `${formId}-message`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-medium text-fg",
									children: "Mensaje"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									id: `${formId}-message`,
									name: "message",
									rows: 5,
									value: values.message,
									placeholder: "La restricción, la persona y lo que tiene que sentirse.",
									"aria-invalid": errors.message ? true : void 0,
									"aria-describedby": errors.message ? `${formId}-message-error` : void 0,
									onChange: (event) => update("message", event.target.value),
									className: "resize-y border border-line bg-bg px-4 py-3 text-fg placeholder:text-muted"
								}),
								errors.message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									id: `${formId}-message-error`,
									className: "text-sm text-racing",
									children: errors.message
								}) : null
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "mt-5 inline-flex h-12 items-center bg-racing px-5 text-sm font-semibold text-bg transition-transform duration-150 ease-out active:scale-[0.96]",
					children: "Preparar mensaje"
				})]
			})]
		})
	});
}
function Field({ id, label, value, error, onChange, type = "text", autoComplete, placeholder }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "grid gap-2",
		htmlFor: id,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-medium text-fg",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				id,
				name: id,
				type,
				value,
				autoComplete,
				placeholder,
				"aria-invalid": error ? true : void 0,
				"aria-describedby": error ? `${id}-error` : void 0,
				onChange: (event) => onChange(event.target.value),
				className: "h-12 border border-line bg-bg px-4 text-fg placeholder:text-muted"
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				id: `${id}-error`,
				className: "text-sm text-racing",
				children: error
			}) : null
		]
	});
}
function Livery() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-2 w-full",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full w-1/2 bg-racing" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full w-2 bg-signal" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full w-12 bg-fg" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full flex-1 bg-racing" })
		]
	});
}
function useSectorClock() {
	const [label, setLabel] = (0, import_react.useState)("01:24.180");
	(0, import_react.useEffect)(() => {
		if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
		const origin = performance.now();
		const base = 84.18;
		const id = window.setInterval(() => {
			const elapsed = base + (performance.now() - origin) / 1e3;
			const minutes = Math.floor(elapsed / 60);
			const seconds = Math.floor(elapsed % 60);
			const millis = Math.floor(elapsed % 1 * 1e3);
			setLabel(`${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}.${String(millis).padStart(3, "0")}`);
		}, 90);
		return () => window.clearInterval(id);
	}, []);
	return label;
}
function Hero() {
	const clock = useSectorClock();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "top",
		className: "relative overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "speedlines pointer-events-none absolute inset-0 opacity-40",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto grid min-h-[calc(100dvh-4rem)] max-w-7xl items-center gap-8 px-5 py-10 md:grid-cols-2 md:px-8 md:py-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rise rise-1 text-kicker font-medium text-signal uppercase",
						children: "Hiller Lozano · Diseñador UX"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "rise rise-2 mt-4 font-poster text-hero text-fg uppercase",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block",
								children: "No diseño pantallas."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-racing",
								children: "Diseño la sensación"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block",
								children: "de llegar primero."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rise rise-3 mt-6 max-w-xl text-lg leading-relaxed text-muted",
						children: "Interfaces con la precisión de un cockpit y el pulso de un opening. Cada interacción tiene trazada: se entra, se decide, se sale."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rise rise-4 mt-8 flex flex-wrap gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#trabajo",
							className: "inline-flex h-12 items-center bg-racing px-5 text-sm font-semibold text-bg transition-transform duration-150 ease-out active:scale-[0.96]",
							children: "Ver los cuatro proyectos"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#sobre",
							className: "inline-flex h-12 items-center border border-line px-5 text-sm font-semibold text-fg transition-colors duration-200 hover:border-fg",
							children: "Sobre mí"
						})]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
					className: "rise rise-5 relative",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "pointer-events-none absolute -top-3 -left-3 h-8 w-8 border-t-2 border-l-2 border-signal",
							"aria-hidden": "true"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "pointer-events-none absolute -right-3 -bottom-3 h-8 w-8 border-r-2 border-b-2 border-racing",
							"aria-hidden": "true"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/portfolio/hero.jpg",
							alt: "Casco de carbono con una franja roja. El visor cerrado refleja un circuito de noche.",
							width: 1792,
							height: 1008,
							className: "aspect-video w-full object-cover"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", {
							className: "mt-3 flex items-center justify-between gap-3 font-poster text-xl tracking-wide text-muted uppercase",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "07 · Visor" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Noche / circuito" })]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative border-t border-line",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mx-auto grid max-w-7xl grid-cols-2 md:grid-cols-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "border-b border-line px-5 py-4 md:border-r md:border-b-0 md:px-8",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-kicker text-muted uppercase",
								children: "Vuelta"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "font-poster text-3xl text-fg",
								children: "01 · Sector UX"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "border-b border-l border-line px-5 py-4 md:border-b-0 md:border-l-0 md:border-r md:px-8",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-kicker text-muted uppercase",
								children: "Tiempo"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "font-poster text-3xl text-signal tabular-nums",
								children: clock
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "border-line px-5 py-4 md:border-r md:px-8",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-kicker text-muted uppercase",
								children: "Compuesto"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "font-poster text-3xl text-fg",
								children: "Claridad"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "border-l border-line px-5 py-4 md:border-l-0 md:px-8",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-kicker text-muted uppercase",
								children: "Condición"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "font-poster text-3xl text-fg",
								children: "Presión real"
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Livery, {})]
			})
		]
	});
}
var links = [
	{
		href: "#trabajo",
		label: "Trabajo"
	},
	{
		href: "#sobre",
		label: "Sobre mí"
	},
	{
		href: "#contacto",
		label: "Contacto"
	}
];
function SiteHeader() {
	const [open, setOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		document.body.style.overflow = open ? "hidden" : "";
		return () => {
			document.body.style.overflow = "";
		};
	}, [open]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-40 border-b border-line bg-bg/90 backdrop-blur-md",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-5 md:px-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: "#top",
					className: "flex items-center gap-3",
					onClick: () => setOpen(false),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid h-11 w-11 place-items-center border border-racing font-poster text-2xl leading-none text-fg",
						children: "HL"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "hidden sm:block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-poster text-2xl leading-none text-fg",
							children: "Hiller Lozano"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-kicker text-muted uppercase",
							children: "Diseñador UX"
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "hidden items-center gap-8 md:flex",
					"aria-label": "Secciones",
					children: links.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: link.href,
						className: "text-sm font-medium text-muted transition-colors duration-200 hover:text-fg",
						children: link.label
					}, link.href))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "hidden items-center gap-2 border border-line px-3 py-2 text-sm text-muted lg:inline-flex",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "h-2 w-2 bg-signal",
								"aria-hidden": "true"
							}), "Disponible"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#contacto",
							className: "hidden h-11 items-center bg-racing px-4 text-sm font-semibold text-bg transition-transform duration-150 ease-out active:scale-[0.96] md:inline-flex",
							children: "Hablemos"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "grid h-11 w-11 place-items-center border border-line text-fg transition-transform duration-150 ease-out active:scale-[0.96] md:hidden",
							"aria-expanded": open,
							"aria-controls": "menu-movil",
							onClick: () => setOpen((value) => !value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "sr-only",
								children: open ? "Cerrar menú" : "Abrir menú"
							}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { "aria-hidden": "true" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { "aria-hidden": "true" })]
						})
					]
				})
			]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			id: "menu-movil",
			className: "border-t border-line bg-bg px-5 py-4 md:hidden",
			"aria-label": "Secciones",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "flex flex-col",
				children: [links.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: link.href,
					className: "flex h-12 items-center font-poster text-3xl text-fg",
					onClick: () => setOpen(false),
					children: link.label
				}) }, link.href)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "pt-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "#contacto",
						className: "inline-flex h-11 items-center bg-racing px-4 text-sm font-semibold text-bg",
						onClick: () => setOpen(false),
						children: "Hablemos"
					})
				})]
			})
		}) : null]
	});
}
function Work() {
	const [active, setActive] = (0, import_react.useState)(null);
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "trabajo",
		className: "scroll-mt-16 border-b border-line",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-5 py-16 md:px-8 md:py-24",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-w-2xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-kicker font-medium text-signal uppercase",
						children: "Trabajo destacado"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-poster text-5xl text-fg uppercase md:text-7xl",
						children: "Cuatro trazadas. Un mismo criterio."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-lg leading-relaxed text-muted",
						children: "Producto, contenido, boxes y ciudad. Distinto contexto, la misma pregunta: qué tiene que decidir la persona, y qué sobra."
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-10 grid gap-4 md:grid-cols-2",
				children: projects.map((project) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => {
						setActive(project);
						setOpen(true);
					},
					className: "group flex h-full w-full flex-col border border-line bg-surface text-left transition-colors duration-200 hover:border-racing",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative aspect-[3/2] overflow-hidden",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: project.image,
							alt: project.alt,
							width: 1728,
							height: 1152,
							loading: "lazy",
							className: "h-full w-full object-cover transition-transform duration-300 ease-out group-hover:scale-105"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "absolute top-3 left-3 bg-bg/85 px-2 font-poster text-2xl text-fg",
							children: project.index
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-1 flex-col gap-3 p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-3 text-sm text-muted",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: project.discipline }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular-nums",
									children: project.year
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-poster text-5xl leading-none text-fg uppercase",
								children: project.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "leading-relaxed text-muted",
								children: project.summary
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "mt-auto inline-flex items-center gap-2 pt-2 text-sm font-semibold text-signal",
								children: ["Ver el caso", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
									"aria-hidden": "true",
									className: "h-4 w-4"
								})]
							})
						]
					})]
				}) }, project.slug))
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open,
			onOpenChange: setOpen,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "case-overlay fixed inset-0 z-50 bg-bg/80" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
				className: "case-panel fixed inset-0 z-50 overflow-y-auto bg-bg p-5 md:inset-6 md:m-auto md:h-fit md:max-h-[calc(100dvh-3rem)] md:max-w-5xl md:border md:border-line md:p-8",
				children: active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CaseStudy, { project: active }) : null
			})] })
		})]
	});
}
function CaseStudy({ project }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start justify-between gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-kicker font-medium text-signal uppercase",
				children: [
					"Caso ",
					project.index,
					" · ",
					project.discipline,
					" · ",
					project.year
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
				className: "inline-flex h-11 shrink-0 items-center gap-2 border border-line px-3 text-sm font-semibold text-fg transition-transform duration-150 ease-out active:scale-[0.96]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
					"aria-hidden": "true",
					className: "h-4 w-4"
				}), "Cerrar"]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 grid gap-8 md:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: project.image,
				alt: project.alt,
				width: 1728,
				height: 1152,
				className: "aspect-[3/2] w-full object-cover"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
					className: "font-poster text-6xl leading-none text-fg uppercase md:text-7xl",
					children: project.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
					className: "mt-4 text-lg leading-relaxed text-muted",
					children: project.summary
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 text-sm text-fg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-muted",
						children: "Rol. "
					}), project.role]
				})
			] })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8 grid gap-6 md:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-poster text-3xl text-fg uppercase",
				children: "Contexto"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 leading-relaxed text-muted",
				children: project.context
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-poster text-3xl text-fg uppercase",
				children: "Problema"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 leading-relaxed text-muted",
				children: project.problem
			})] })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-poster text-3xl text-fg uppercase",
				children: "Qué cambió en el diseño"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-4 grid gap-3 md:grid-cols-3",
				children: project.moves.map((move, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "border border-line bg-surface p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-poster text-2xl text-racing",
						children: ["0", index + 1]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 leading-relaxed text-fg",
						children: move
					})]
				}, move))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-8 border-l-4 border-racing bg-surface p-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-poster text-3xl text-signal uppercase",
				children: "Resultado"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-3xl text-lg leading-relaxed text-fg",
				children: project.outcome
			})]
		})
	] });
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			href: "#trabajo",
			className: "skip",
			children: "Saltar al trabajo"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Work, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(About, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Contact, {})
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
			className: "border-t border-line",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Livery, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-7xl flex-col gap-2 px-5 py-6 text-sm text-muted md:flex-row md:items-center md:justify-between md:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					site.name,
					" · ",
					site.role
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Automovilismo × anime. Hecho para decidir rápido." })]
			})]
		})
	] });
}
//#endregion
export { Home as component };
