# Hiller Lozano

Portafolio de Hiller Lozano, diseñador UX. Hero, cuatro proyectos, sobre mí y contacto. Visual de circuito nocturno: carbono, rojo de competición y ámbar de faro.

## Requisitos

- Node.js 22

## Arranque local

```bash
npm install
npm run dev
```

El sitio queda en [http://localhost:8080](http://localhost:8080).

## Producción

```bash
npm run build
npm run preview
```

`npm run build` también prepara el despliegue en Vercel (`vercel.json`).

## Subir a GitHub

Este paquete ya incluye el primer commit. Si partes del zip:

```bash
unzip hiller-lozano.zip -d hiller-lozano
cd hiller-lozano
git init
git add .
git commit -m "Portafolio de Hiller Lozano"
```

Crea un repositorio vacío en GitHub (sin README) y conecta el remoto:

```bash
git remote add origin https://github.com/TU_USUARIO/hiller-lozano.git
git branch -M main
git push -u origin main
```

Con GitHub CLI, en un solo paso:

```bash
gh repo create hiller-lozano --public --source=. --remote=origin --push
```

El correo del formulario está en `src/data/projects.ts` (`site.email`). Cámbialo antes de publicar si no es el definitivo.
