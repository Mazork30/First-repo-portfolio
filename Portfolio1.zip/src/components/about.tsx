import { principles } from "@/data/projects";

export function About() {
  return (
    <section id="sobre" className="scroll-mt-16 border-b border-line">
      <div className="mx-auto grid max-w-7xl gap-10 px-5 py-16 md:grid-cols-[minmax(0,0.85fr)_minmax(0,1.15fr)] md:px-8 md:py-24">
        <figure>
          <img
            src="/portfolio/about.jpg"
            alt="Casco de carreras cerrado sobre un plinto de carbono, con una franja roja y un filete ámbar."
            width={1200}
            height={1600}
            loading="lazy"
            className="aspect-[3/4] w-full object-cover"
          />
          <figcaption className="mt-3 text-sm text-muted">
            Visor abajo. La decisión, delante. El retrato puede esperar.
          </figcaption>
        </figure>

        <div>
          <p className="text-kicker font-medium text-signal uppercase">Sobre mí</p>
          <h2 className="mt-3 font-poster text-5xl text-fg uppercase md:text-7xl">
            Entre el box y el storyboard.
          </h2>
          <div className="mt-6 space-y-4 text-lg leading-relaxed text-muted">
            <p>
              Me muevo entre dos obsesiones que parecen lejanas y no lo son. El
              automovilismo enseña a jerarquizar bajo presión: lo que no se lee
              a fondo, no existe. El anime enseña el ritmo: un encuadre, una
              pausa, un golpe.
            </p>
            <p>
              Diseño productos con las dos cosas a la vez. Investigación con
              gente real, arquitectura que aguanta, prototipos que se pueden
              usar y sistemas que no se rompen en el segundo release. No
              colecciono pantallas. Colecciono decisiones que se sienten obvias
              después, y valientes antes.
            </p>
            <p className="text-fg">
              Estoy disponible para productos que necesiten claridad, carácter
              y una mano que sepa cuándo acelerar y cuándo levantar.
            </p>
          </div>

          <ul className="mt-8 grid gap-3 sm:grid-cols-2">
            {principles.map((item) => (
              <li key={item.index} className="border border-line bg-surface p-4">
                <span className="font-poster text-2xl text-racing">{item.index}</span>
                <h3 className="mt-1 font-poster text-3xl leading-none text-fg uppercase">
                  {item.title}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-muted">{item.copy}</p>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}
