export function Livery() {
  return (
    <div className="flex h-2 w-full" aria-hidden="true">
      <div className="h-full w-1/2 bg-racing" />
      <div className="h-full w-2 bg-signal" />
      <div className="h-full w-12 bg-fg" />
      <div className="h-full flex-1 bg-racing" />
    </div>
  );
}
