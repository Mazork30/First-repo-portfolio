import { useEffect, useState } from "react";
import { Menu, X } from "lucide-react";

const links = [
  { href: "#trabajo", label: "Trabajo" },
  { href: "#sobre", label: "Sobre mí" },
  { href: "#contacto", label: "Contacto" },
];

export function SiteHeader() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <header className="sticky top-0 z-40 border-b border-line bg-bg/90 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-5 md:px-8">
        <a href="#top" className="flex items-center gap-3" onClick={() => setOpen(false)}>
          <span className="grid h-11 w-11 place-items-center border border-racing font-poster text-2xl leading-none text-fg">
            HL
          </span>
          <span className="hidden sm:block">
            <span className="block font-poster text-2xl leading-none text-fg">Hiller Lozano</span>
            <span className="block text-kicker text-muted uppercase">Diseñador UX</span>
          </span>
        </a>

        <nav className="hidden items-center gap-8 md:flex" aria-label="Secciones">
          {links.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="text-sm font-medium text-muted transition-colors duration-200 hover:text-fg"
            >
              {link.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <span className="hidden items-center gap-2 border border-line px-3 py-2 text-sm text-muted lg:inline-flex">
            <span className="h-2 w-2 bg-signal" aria-hidden="true" />
            Disponible
          </span>
          <a
            href="#contacto"
            className="hidden h-11 items-center bg-racing px-4 text-sm font-semibold text-bg transition-transform duration-150 ease-out active:scale-[0.96] md:inline-flex"
          >
            Hablemos
          </a>
          <button
            type="button"
            className="grid h-11 w-11 place-items-center border border-line text-fg transition-transform duration-150 ease-out active:scale-[0.96] md:hidden"
            aria-expanded={open}
            aria-controls="menu-movil"
            onClick={() => setOpen((value) => !value)}
          >
            <span className="sr-only">{open ? "Cerrar menú" : "Abrir menú"}</span>
            {open ? <X aria-hidden="true" /> : <Menu aria-hidden="true" />}
          </button>
        </div>
      </div>

      {open ? (
        <nav
          id="menu-movil"
          className="border-t border-line bg-bg px-5 py-4 md:hidden"
          aria-label="Secciones"
        >
          <ul className="flex flex-col">
            {links.map((link) => (
              <li key={link.href}>
                <a
                  href={link.href}
                  className="flex h-12 items-center font-poster text-3xl text-fg"
                  onClick={() => setOpen(false)}
                >
                  {link.label}
                </a>
              </li>
            ))}
            <li className="pt-2">
              <a
                href="#contacto"
                className="inline-flex h-11 items-center bg-racing px-4 text-sm font-semibold text-bg"
                onClick={() => setOpen(false)}
              >
                Hablemos
              </a>
            </li>
          </ul>
        </nav>
      ) : null}
    </header>
  );
}
