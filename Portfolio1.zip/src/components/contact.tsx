import { useId, useState, type FormEvent } from "react";
import { Check, Copy, Mail } from "lucide-react";
import { z } from "zod";
import { site } from "@/data/projects";

const schema = z.object({
  name: z.string().trim().min(2, "Dime cómo llamarte."),
  email: z.string().trim().email("Ese correo no parece válido."),
  project: z.string().trim().min(2, "Cuéntame el proyecto en una línea."),
  message: z.string().trim().min(12, "Un poco más de contexto, aunque sea breve."),
});

type FormValues = z.infer<typeof schema>;
type Field = keyof FormValues;
type Errors = Partial<Record<Field, string>>;

const empty: FormValues = { name: "", email: "", project: "", message: "" };

function compose(values: FormValues) {
  return `Hola Hiller,\n\nSoy ${values.name} (${values.email}).\nProyecto: ${values.project}\n\n${values.message}`;
}

function mailto(values: FormValues) {
  const subject = encodeURIComponent(`Proyecto: ${values.project}`);
  const body = encodeURIComponent(compose(values));
  return `mailto:${site.email}?subject=${subject}&body=${body}`;
}

export function Contact() {
  const formId = useId();
  const [values, setValues] = useState<FormValues>(empty);
  const [errors, setErrors] = useState<Errors>({});
  const [ready, setReady] = useState<FormValues | null>(null);
  const [copied, setCopied] = useState(false);

  function update(field: Field, value: string) {
    setValues((current) => ({ ...current, [field]: value }));
    setErrors((current) => ({ ...current, [field]: undefined }));
  }

  function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const parsed = schema.safeParse(values);
    if (!parsed.success) {
      const next: Errors = {};
      for (const issue of parsed.error.issues) {
        const key = issue.path[0];
        if (typeof key === "string" && !next[key as Field]) next[key as Field] = issue.message;
      }
      setErrors(next);
      setReady(null);
      return;
    }
    setErrors({});
    setReady(parsed.data);
    setCopied(false);
  }

  async function copyMessage() {
    if (!ready) return;
    try {
      await navigator.clipboard.writeText(compose(ready));
      setCopied(true);
    } catch {
      setCopied(false);
    }
  }

  return (
    <section id="contacto" className="scroll-mt-16">
      <div className="mx-auto grid max-w-7xl gap-10 px-5 py-16 md:grid-cols-2 md:px-8 md:py-24">
        <div>
          <p className="text-kicker font-medium text-signal uppercase">Contacto</p>
          <h2 className="mt-3 font-poster text-5xl text-fg uppercase md:text-7xl">
            Cuéntame la próxima curva.
          </h2>
          <p className="mt-4 max-w-xl text-lg leading-relaxed text-muted">
            Qué tiene que lograr la persona al otro lado, qué restricción no se
            negocia y cómo debería sentirse el producto en los primeros diez
            segundos. Con eso alcanza para una primera lectura honesta.
          </p>
          <a
            href={`mailto:${site.email}`}
            className="mt-6 inline-flex items-center gap-2 text-lg font-medium text-signal"
          >
            <Mail aria-hidden="true" className="h-5 w-5" />
            {site.email}
          </a>
          <p className="mt-4 max-w-md text-sm leading-relaxed text-muted">
            Respondo en persona. Sin newsletter y sin automatización. El
            formulario prepara el mensaje para que lo envíes tú.
          </p>
        </div>

        {ready ? (
          <div className="border border-line bg-surface p-5 md:p-6" role="status">
            <p className="font-poster text-4xl text-fg uppercase">Mensaje listo</p>
            <p className="mt-2 text-muted">
              Cópialo o ábrelo en tu correo. Llega directo, sin intermediarios.
            </p>
            <pre className="mt-4 overflow-x-auto border border-line bg-bg p-4 text-sm leading-relaxed whitespace-pre-wrap text-fg">
              {compose(ready)}
            </pre>
            <div className="mt-4 flex flex-wrap gap-3">
              <button
                type="button"
                onClick={copyMessage}
                className="inline-flex h-11 items-center gap-2 bg-racing px-4 text-sm font-semibold text-bg transition-transform duration-150 ease-out active:scale-[0.96]"
              >
                {copied ? <Check aria-hidden="true" className="h-4 w-4" /> : <Copy aria-hidden="true" className="h-4 w-4" />}
                {copied ? "Copiado" : "Copiar mensaje"}
              </button>
              <a
                href={mailto(ready)}
                className="inline-flex h-11 items-center border border-line px-4 text-sm font-semibold text-fg"
              >
                Abrir en el correo
              </a>
              <button
                type="button"
                onClick={() => {
                  setReady(null);
                  setCopied(false);
                }}
                className="inline-flex h-11 items-center px-4 text-sm font-semibold text-muted"
              >
                Escribir otro
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={onSubmit} noValidate className="border border-line bg-surface p-5 md:p-6">
            <div className="grid gap-4">
              <Field
                id={`${formId}-name`}
                label="Nombre"
                value={values.name}
                error={errors.name}
                autoComplete="name"
                onChange={(value) => update("name", value)}
              />
              <Field
                id={`${formId}-email`}
                label="Correo"
                type="email"
                value={values.email}
                error={errors.email}
                autoComplete="email"
                onChange={(value) => update("email", value)}
              />
              <Field
                id={`${formId}-project`}
                label="Proyecto"
                value={values.project}
                error={errors.project}
                placeholder="Una app, un rediseño, un sistema"
                onChange={(value) => update("project", value)}
              />
              <label className="grid gap-2" htmlFor={`${formId}-message`}>
                <span className="text-sm font-medium text-fg">Mensaje</span>
                <textarea
                  id={`${formId}-message`}
                  name="message"
                  rows={5}
                  value={values.message}
                  placeholder="La restricción, la persona y lo que tiene que sentirse."
                  aria-invalid={errors.message ? true : undefined}
                  aria-describedby={errors.message ? `${formId}-message-error` : undefined}
                  onChange={(event) => update("message", event.target.value)}
                  className="resize-y border border-line bg-bg px-4 py-3 text-fg placeholder:text-muted"
                />
                {errors.message ? (
                  <span id={`${formId}-message-error`} className="text-sm text-racing">
                    {errors.message}
                  </span>
                ) : null}
              </label>
            </div>
            <button
              type="submit"
              className="mt-5 inline-flex h-12 items-center bg-racing px-5 text-sm font-semibold text-bg transition-transform duration-150 ease-out active:scale-[0.96]"
            >
              Preparar mensaje
            </button>
          </form>
        )}
      </div>
    </section>
  );
}

function Field({
  id,
  label,
  value,
  error,
  onChange,
  type = "text",
  autoComplete,
  placeholder,
}: {
  id: string;
  label: string;
  value: string;
  error?: string;
  onChange: (value: string) => void;
  type?: string;
  autoComplete?: string;
  placeholder?: string;
}) {
  return (
    <label className="grid gap-2" htmlFor={id}>
      <span className="text-sm font-medium text-fg">{label}</span>
      <input
        id={id}
        name={id}
        type={type}
        value={value}
        autoComplete={autoComplete}
        placeholder={placeholder}
        aria-invalid={error ? true : undefined}
        aria-describedby={error ? `${id}-error` : undefined}
        onChange={(event) => onChange(event.target.value)}
        className="h-12 border border-line bg-bg px-4 text-fg placeholder:text-muted"
      />
      {error ? (
        <span id={`${id}-error`} className="text-sm text-racing">
          {error}
        </span>
      ) : null}
    </label>
  );
}
