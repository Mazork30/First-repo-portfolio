import { useEffect, useState } from "react";
import { Livery } from "@/components/livery";

function useSectorClock() {
  const [label, setLabel] = useState("01:24.180");

  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) return;

    const origin = performance.now();
    const base = 84.18;
    const id = window.setInterval(() => {
      const elapsed = base + (performance.now() - origin) / 1000;
      const minutes = Math.floor(elapsed / 60);
      const seconds = Math.floor(elapsed % 60);
      const millis = Math.floor((elapsed % 1) * 1000);
      setLabel(
        `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}.${String(millis).padStart(3, "0")}`,
      );
    }, 90);

    return () => window.clearInterval(id);
  }, []);

  return label;
}

export function Hero() {
  const clock = useSectorClock();

  return (
    <section id="top" className="relative overflow-hidden">
      <div className="speedlines pointer-events-none absolute inset-0 opacity-40" aria-hidden="true" />
      <div className="relative mx-auto grid min-h-[calc(100dvh-4rem)] max-w-7xl items-center gap-8 px-5 py-10 md:grid-cols-2 md:px-8 md:py-12">
        <div>
          <p className="rise rise-1 text-kicker font-medium text-signal uppercase">
            Hiller Lozano · Diseñador UX
          </p>
          <h1 className="rise rise-2 mt-4 font-poster text-hero text-fg uppercase">
            <span className="block">No diseño pantallas.</span>
            <span className="block text-racing">Diseño la sensación</span>
            <span className="block">de llegar primero.</span>
          </h1>
          <p className="rise rise-3 mt-6 max-w-xl text-lg leading-relaxed text-muted">
            Interfaces con la precisión de un cockpit y el pulso de un opening.
            Cada interacción tiene trazada: se entra, se decide, se sale.
          </p>
          <div className="rise rise-4 mt-8 flex flex-wrap gap-3">
            <a
              href="#trabajo"
              className="inline-flex h-12 items-center bg-racing px-5 text-sm font-semibold text-bg transition-transform duration-150 ease-out active:scale-[0.96]"
            >
              Ver los cuatro proyectos
            </a>
            <a
              href="#sobre"
              className="inline-flex h-12 items-center border border-line px-5 text-sm font-semibold text-fg transition-colors duration-200 hover:border-fg"
            >
              Sobre mí
            </a>
          </div>
        </div>

        <figure className="rise rise-5 relative">
          <div className="pointer-events-none absolute -top-3 -left-3 h-8 w-8 border-t-2 border-l-2 border-signal" aria-hidden="true" />
          <div className="pointer-events-none absolute -right-3 -bottom-3 h-8 w-8 border-r-2 border-b-2 border-racing" aria-hidden="true" />
          <img
            src="/portfolio/hero.jpg"
            alt="Casco de carbono con una franja roja. El visor cerrado refleja un circuito de noche."
            width={1792}
            height={1008}
            className="aspect-video w-full object-cover"
          />
          <figcaption className="mt-3 flex items-center justify-between gap-3 font-poster text-xl tracking-wide text-muted uppercase">
            <span>07 · Visor</span>
            <span>Noche / circuito</span>
          </figcaption>
        </figure>
      </div>

      <div className="relative border-t border-line">
        <dl className="mx-auto grid max-w-7xl grid-cols-2 md:grid-cols-4">
          <div className="border-b border-line px-5 py-4 md:border-r md:border-b-0 md:px-8">
            <dt className="text-kicker text-muted uppercase">Vuelta</dt>
            <dd className="font-poster text-3xl text-fg">01 · Sector UX</dd>
          </div>
          <div className="border-b border-l border-line px-5 py-4 md:border-b-0 md:border-l-0 md:border-r md:px-8">
            <dt className="text-kicker text-muted uppercase">Tiempo</dt>
            <dd className="font-poster text-3xl text-signal tabular-nums">{clock}</dd>
          </div>
          <div className="border-line px-5 py-4 md:border-r md:px-8">
            <dt className="text-kicker text-muted uppercase">Compuesto</dt>
            <dd className="font-poster text-3xl text-fg">Claridad</dd>
          </div>
          <div className="border-l border-line px-5 py-4 md:border-l-0 md:px-8">
            <dt className="text-kicker text-muted uppercase">Condición</dt>
            <dd className="font-poster text-3xl text-fg">Presión real</dd>
          </div>
        </dl>
        <Livery />
      </div>
    </section>
  );
}
