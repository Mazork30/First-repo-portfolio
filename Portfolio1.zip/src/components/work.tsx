import { useState } from "react";
import * as Dialog from "@radix-ui/react-dialog";
import { ArrowUpRight, X } from "lucide-react";
import { projects, type Project } from "@/data/projects";

export function Work() {
  const [active, setActive] = useState<Project | null>(null);
  const [open, setOpen] = useState(false);

  return (
    <section id="trabajo" className="scroll-mt-16 border-b border-line">
      <div className="mx-auto max-w-7xl px-5 py-16 md:px-8 md:py-24">
        <div className="max-w-2xl">
          <p className="text-kicker font-medium text-signal uppercase">Trabajo destacado</p>
          <h2 className="mt-3 font-poster text-5xl text-fg uppercase md:text-7xl">
            Cuatro trazadas. Un mismo criterio.
          </h2>
          <p className="mt-4 text-lg leading-relaxed text-muted">
            Producto, contenido, boxes y ciudad. Distinto contexto, la misma
            pregunta: qué tiene que decidir la persona, y qué sobra.
          </p>
        </div>

        <ul className="mt-10 grid gap-4 md:grid-cols-2">
          {projects.map((project) => (
            <li key={project.slug}>
              <button
                type="button"
                onClick={() => {
                  setActive(project);
                  setOpen(true);
                }}
                className="group flex h-full w-full flex-col border border-line bg-surface text-left transition-colors duration-200 hover:border-racing"
              >
                <div className="relative aspect-[3/2] overflow-hidden">
                  <img
                    src={project.image}
                    alt={project.alt}
                    width={1728}
                    height={1152}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-300 ease-out group-hover:scale-105"
                  />
                  <span className="absolute top-3 left-3 bg-bg/85 px-2 font-poster text-2xl text-fg">
                    {project.index}
                  </span>
                </div>
                <div className="flex flex-1 flex-col gap-3 p-5">
                  <div className="flex items-center justify-between gap-3 text-sm text-muted">
                    <span>{project.discipline}</span>
                    <span className="tabular-nums">{project.year}</span>
                  </div>
                  <h3 className="font-poster text-5xl leading-none text-fg uppercase">
                    {project.title}
                  </h3>
                  <p className="leading-relaxed text-muted">{project.summary}</p>
                  <span className="mt-auto inline-flex items-center gap-2 pt-2 text-sm font-semibold text-signal">
                    Ver el caso
                    <ArrowUpRight aria-hidden="true" className="h-4 w-4" />
                  </span>
                </div>
              </button>
            </li>
          ))}
        </ul>
      </div>

      <Dialog.Root open={open} onOpenChange={setOpen}>
        <Dialog.Portal>
          <Dialog.Overlay className="case-overlay fixed inset-0 z-50 bg-bg/80" />
          <Dialog.Content className="case-panel fixed inset-0 z-50 overflow-y-auto bg-bg p-5 md:inset-6 md:m-auto md:h-fit md:max-h-[calc(100dvh-3rem)] md:max-w-5xl md:border md:border-line md:p-8">
            {active ? <CaseStudy project={active} /> : null}
          </Dialog.Content>
        </Dialog.Portal>
      </Dialog.Root>
    </section>
  );
}

function CaseStudy({ project }: { project: Project }) {
  return (
    <article>
      <div className="flex items-start justify-between gap-4">
        <p className="text-kicker font-medium text-signal uppercase">
          Caso {project.index} · {project.discipline} · {project.year}
        </p>
        <Dialog.Close className="inline-flex h-11 shrink-0 items-center gap-2 border border-line px-3 text-sm font-semibold text-fg transition-transform duration-150 ease-out active:scale-[0.96]">
          <X aria-hidden="true" className="h-4 w-4" />
          Cerrar
        </Dialog.Close>
      </div>

      <div className="mt-6 grid gap-8 md:grid-cols-2">
        <img
          src={project.image}
          alt={project.alt}
          width={1728}
          height={1152}
          className="aspect-[3/2] w-full object-cover"
        />
        <div>
          <Dialog.Title className="font-poster text-6xl leading-none text-fg uppercase md:text-7xl">
            {project.title}
          </Dialog.Title>
          <Dialog.Description className="mt-4 text-lg leading-relaxed text-muted">
            {project.summary}
          </Dialog.Description>
          <p className="mt-4 text-sm text-fg">
            <span className="text-muted">Rol. </span>
            {project.role}
          </p>
        </div>
      </div>

      <div className="mt-8 grid gap-6 md:grid-cols-2">
        <section>
          <h3 className="font-poster text-3xl text-fg uppercase">Contexto</h3>
          <p className="mt-2 leading-relaxed text-muted">{project.context}</p>
        </section>
        <section>
          <h3 className="font-poster text-3xl text-fg uppercase">Problema</h3>
          <p className="mt-2 leading-relaxed text-muted">{project.problem}</p>
        </section>
      </div>

      <section className="mt-8">
        <h3 className="font-poster text-3xl text-fg uppercase">Qué cambió en el diseño</h3>
        <ol className="mt-4 grid gap-3 md:grid-cols-3">
          {project.moves.map((move, index) => (
            <li key={move} className="border border-line bg-surface p-4">
              <span className="font-poster text-2xl text-racing">0{index + 1}</span>
              <p className="mt-2 leading-relaxed text-fg">{move}</p>
            </li>
          ))}
        </ol>
      </section>

      <section className="mt-8 border-l-4 border-racing bg-surface p-5">
        <h3 className="font-poster text-3xl text-signal uppercase">Resultado</h3>
        <p className="mt-2 max-w-3xl text-lg leading-relaxed text-fg">{project.outcome}</p>
      </section>
    </article>
  );
}
