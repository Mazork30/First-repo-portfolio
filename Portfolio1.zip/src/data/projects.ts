export const site = {
  name: "Hiller Lozano",
  role: "Diseñador UX",
  email: "hola@hillerlozano.design",
};

export type Project = {
  slug: string;
  index: string;
  title: string;
  discipline: string;
  year: string;
  summary: string;
  image: string;
  alt: string;
  role: string;
  context: string;
  problem: string;
  moves: string[];
  outcome: string;
};

export const projects: Project[] = [
  {
    slug: "veloce",
    index: "01",
    title: "Veloce",
    discipline: "Producto",
    year: "2025",
    summary:
      "HUD de telemetría para pilotos amateur. El dato crítico se lee sin apartar la vista de la trazada.",
    image: "/portfolio/veloce.jpg",
    alt: "Vista desde el cockpit de un auto de carreras de noche, volante y luces ámbar sobre asfalto mojado.",
    role: "Diseño de producto, de la investigación al prototipo",
    context:
      "Un equipo de simracing quería sacar la telemetría del portátil y ponerla en el visor. Los pilotos amateur llegaban a la curva mirando una tabla, no el ápice.",
    problem:
      "Las apps de datos heredan el lenguaje del ingeniero: todo visible, todo igual de importante. En pista eso es ruido. El piloto necesita una sola verdad y el resto en silencio.",
    moves: [
      "Sesiones en simulador para ver dónde se iba la mirada en los últimos doscientos metros.",
      "Tres niveles: delta, sector, y todo lo demás oculto hasta la recta.",
      "Prototipo probado con guantes y el auto en movimiento, no en un escritorio quieto.",
    ],
    outcome:
      "El delta vive en el centro del campo visual. La marcha y la temperatura solo aparecen cuando el ritmo baja. La interfaz deja de competir con la curva.",
  },
  {
    slug: "frame-24",
    index: "02",
    title: "Frame 24",
    discipline: "Contenido",
    year: "2024",
    summary:
      "Descubrimiento para una plataforma de anime. El inicio se comporta como un opening, no como un estante.",
    image: "/portfolio/frame.jpg",
    alt: "Calle de noche bajo la lluvia, luces ámbar y rojas reflejadas en el asfalto, vista a través de un vidrio mojado.",
    role: "UX de contenido y arquitectura del primer visionado",
    context:
      "Una plataforma independiente de anime tenía catálogo de sobra y una portada que parecía un supermercado: filas, carátulas y cero pulso.",
    problem:
      "La gente no se va por falta de títulos. Se va porque nada le dice cuál es el siguiente. El scroll infinito diluye el deseo.",
    moves: [
      "Mapa de la primera sesión: de la llegada al play, sin un menú de géneros de por medio.",
      "Una pieza principal que cambia como una secuencia: frío, título, motivo y un solo llamado.",
      "Seguir viendo deja de ser una fila más y pasa a ser el cliffhanger de la sesión.",
    ],
    outcome:
      "Una sola decisión dominante por pantalla. El catálogo sigue ahí, detrás de un gesto, no delante de la emoción.",
  },
  {
    slug: "pitwall",
    index: "03",
    title: "Pitwall",
    discipline: "Operaciones",
    year: "2025",
    summary:
      "Coordinación de boxes para endurance amateur. Stint, gomas y radio en una tira que se confirma con el pulgar.",
    image: "/portfolio/pitwall.jpg",
    alt: "Garage de boxes de noche, nariz roja de un prototipo y luces de trabajo cálidas.",
    role: "Diseño de operaciones y flujos bajo presión",
    context:
      "Una escudería de endurance corría con una hoja de cálculo, tres radios y la memoria del jefe de box. En la hora dieciocho, de noche, eso se cae.",
    problem:
      "La información existía, repartida. Confirmar un cambio de gomas pedía salir de la hoja, buscar la ventana y volver a hablar. Bajo bandera no hay tiempo para navegar.",
    moves: [
      "Observación de un stint entero, anotando qué se preguntaba en voz alta.",
      "Una tira fija: piloto, gomas, ventana, combustible. Lo demás se abre hacia abajo.",
      "Confirmaciones grandes, de pulgar, con estados imposibles de confundir: listo, en curso, hecho.",
    ],
    outcome:
      "El box deja de improvisar la secuencia. La pantalla no pide precisión de oficina: pide una decisión y la registra.",
  },
  {
    slug: "senda",
    index: "04",
    title: "Senda",
    discipline: "Wayfinding",
    year: "2023",
    summary:
      "Señalética digital para un intercambiador. Tres segundos, una flecha, cero ornamento.",
    image: "/portfolio/senda.jpg",
    alt: "Gran vestíbulo de una estación al anochecer, luces ámbar en retícula y un reflejo rojo en el suelo.",
    role: "Wayfinding y sistema de señales en pantalla",
    context:
      "Un intercambiador urbano renovaba pantallas que repetían el mapa completo en cada punto. La gente se detenía en mitad del flujo.",
    problem:
      "Un mapa es una herramienta de escritorio. En un andén es una excusa para dudar. Quien camina con una maleta no quiere entender el sistema: quiere la salida.",
    moves: [
      "Recorridos con personas entre andén, calle y correspondencia.",
      "Regla de tres: nunca más de tres opciones en una pantalla de decisión.",
      "Lenguaje de circuito: número enorme, una flecha, minutos a pie. El mapa queda para quien lo pide.",
    ],
    outcome:
      "La pantalla empuja en lugar de retener. Quien necesita el sistema completo lo abre. Quien solo necesita salir, sale.",
  },
];

export const principles = [
  {
    index: "01",
    title: "Claridad a fondo",
    copy: "Si no se lee en un vistazo, no está diseñado. La jerarquía es una decisión, no un adorno.",
  },
  {
    index: "02",
    title: "Ritmo de opening",
    copy: "El motion marca un cambio de estado. Si no cambia nada, la pantalla se queda quieta.",
  },
  {
    index: "03",
    title: "El piloto manda",
    copy: "Primero la gente bajo presión real. La livery llega después, y solo si ayuda a decidir.",
  },
  {
    index: "04",
    title: "Sistema, no piezas",
    copy: "Reglas que aguantan el siguiente release. Un producto no es una colección de pantallas.",
  },
];
