import { createFileRoute } from "@tanstack/react-router";
import { About } from "@/components/about";
import { Contact } from "@/components/contact";
import { Hero } from "@/components/hero";
import { Livery } from "@/components/livery";
import { SiteHeader } from "@/components/site-header";
import { Work } from "@/components/work";
import { site } from "@/data/projects";

export const Route = createFileRoute("/")({
  component: Home,
});

function Home() {
  return (
    <>
      <a href="#trabajo" className="skip">
        Saltar al trabajo
      </a>
      <SiteHeader />
      <main>
        <Hero />
        <Work />
        <About />
        <Contact />
      </main>
      <footer className="border-t border-line">
        <Livery />
        <div className="mx-auto flex max-w-7xl flex-col gap-2 px-5 py-6 text-sm text-muted md:flex-row md:items-center md:justify-between md:px-8">
          <p>
            {site.name} · {site.role}
          </p>
          <p>Automovilismo × anime. Hecho para decidir rápido.</p>
        </div>
      </footer>
    </>
  );
}
